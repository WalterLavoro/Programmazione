// prompt()
let x = parseFloat(window.prompt("Inserisci un numero"));
let y = parseFloat(window.prompt("Inserisci un numero"));

window.alert("Ciao");

let aa = 2;
let xx = 1 + (aa *= 2);

console.log(aa);
console.log(xx);
