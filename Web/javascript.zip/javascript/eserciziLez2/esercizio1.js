
let nome = "Mario";

// js che usa il dom ... html
// document.write("<h1>Ciao " + nome + "</h1>");

document.getElementById("mioesempio").innerHTML = "<h1>Ciao " + nome + "</h1>";