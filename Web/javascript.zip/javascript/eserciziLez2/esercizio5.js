let giorni = 'lunedi,martedi,mercoledi,giovedi,venerdi,sabato,domenica';

//dom
document.getElementById("ese5").innerHTML = giorni.replaceAll(',' , '<br>');

