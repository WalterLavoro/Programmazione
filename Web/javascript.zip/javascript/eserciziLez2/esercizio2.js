
let mionumero = 100;

document.getElementById("mioesempio1").innerHTML = "Valore :" + mionumero;

mionumero = 70;

document.getElementById("mioesempio2").innerHTML = "Valore :" + mionumero;