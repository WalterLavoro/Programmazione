function test2() {

    window.alert('ciaoooo')

} 